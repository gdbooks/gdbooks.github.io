ArrayPainter 1.1

Run ArrayPainter by double clicking the webstart.jnlp java file.
For more information, see www.arraypainter.com

/Stephan Ryer